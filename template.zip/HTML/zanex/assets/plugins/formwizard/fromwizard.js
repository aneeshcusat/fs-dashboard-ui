$(function() {
    $('#smartwizard3').smartWizard({
		selected: 0, // Initial selected step, 0 = first step
		theme: 'dots', // theme for the wizard, related css need to include for other than default theme;

	});
});